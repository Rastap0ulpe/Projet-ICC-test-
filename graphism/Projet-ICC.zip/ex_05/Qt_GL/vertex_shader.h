#pragma once

enum Vertex_Shader_Attribute_Id {
  SommetId = 0,
  CouleurId,
};
